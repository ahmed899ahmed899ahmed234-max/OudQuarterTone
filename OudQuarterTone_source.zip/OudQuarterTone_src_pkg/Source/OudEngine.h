// OudEngine.h - header-only DSP core (no JUCE dependency)
//
// Guitar in (mono)  ->  pitch tracking (YIN)  ->  maqam / quarter-tone mapping
//                   ->  Karplus-Strong oud-style plucked strings  ->  stereo out
#pragma once
#include <algorithm>
#include <array>
#include <cmath>
#include <cstdint>
#include <vector>

namespace oud
{
constexpr double kPi = 3.14159265358979323846;

inline double midiToHz (double m) { return 440.0 * std::pow (2.0, (m - 69.0) / 12.0); }
inline double hzToMidi (double f) { return 69.0 + 12.0 * std::log2 (f / 440.0); }

//------------------------------------------------------------------------------
// Maqam tables: extra offset in CENTS applied to a played semitone,
// indexed by its interval (0..11 semitones) above the chosen tonic.
//   0 = Off (12-TET)   1 = Rast   2 = Bayati   3 = Sikah   4 = Custom
//
//  Rast   (tonic C): E and B lowered a quarter tone  -> C D E<half-flat> F G A B<half-flat>
//  Bayati (tonic D): E lowered a quarter tone        -> D E<half-flat> F G A Bb C
//  Sikah  (tonic E): E and B lowered a quarter tone  -> E<half-flat> F G A B<half-flat> C D
//  (Sikah's tonic is itself the half-flat note.)
inline std::array<float, 12> maqamOffsets (int maqam, const std::array<float, 12>& custom)
{
    std::array<float, 12> t {};
    switch (maqam)
    {
        case 1: t[4] = -50.0f; t[11] = -50.0f; break;   // Rast
        case 2: t[2] = -50.0f;                 break;   // Bayati
        case 3: t[0] = -50.0f; t[7] = -50.0f;  break;   // Sikah
        case 4: t = custom;                    break;
        default: break;
    }
    return t;
}

//------------------------------------------------------------------------------
struct Biquad
{
    float b0 = 1, b1 = 0, b2 = 0, a1 = 0, a2 = 0, z1 = 0, z2 = 0;

    void reset() { z1 = z2 = 0; }

    float process (float x)
    {
        const float y = b0 * x + z1;
        z1 = b1 * x - a1 * y + z2;
        z2 = b2 * x - a2 * y;
        return y;
    }

    void setLowpass (double sr, double f, double q)
    {
        const double w = 2.0 * kPi * f / sr, c = std::cos (w), al = std::sin (w) / (2.0 * q);
        const double a0 = 1.0 + al;
        b0 = (float) (((1.0 - c) * 0.5) / a0);
        b1 = (float) ((1.0 - c) / a0);
        b2 = b0;
        a1 = (float) (-2.0 * c / a0);
        a2 = (float) ((1.0 - al) / a0);
    }

    void setPeak (double sr, double f, double q, double gainDb)
    {
        const double A = std::pow (10.0, gainDb / 40.0);
        const double w = 2.0 * kPi * f / sr, c = std::cos (w), al = std::sin (w) / (2.0 * q);
        const double a0 = 1.0 + al / A;
        b0 = (float) ((1.0 + al * A) / a0);
        b1 = (float) (-2.0 * c / a0);
        b2 = (float) ((1.0 - al * A) / a0);
        a1 = b1;
        a2 = (float) ((1.0 - al / A) / a0);
    }
};

//------------------------------------------------------------------------------
// YIN pitch detector running on a decimated (~12 kHz) copy of the input.
class PitchDetector
{
public:
    struct Result
    {
        bool voiced = false;
        double hz = 0.0;
    };

    void prepare (double sampleRate)
    {
        sr = sampleRate;
        decim = std::max (1, (int) std::lround (sr / 12000.0));
        dsr = sr / decim;
        tauMax = (int) std::ceil (dsr / 75.0) + 2;             // lowest note ~75 Hz
        tauMin = std::max (2, (int) std::floor (dsr / 1500.0)); // highest ~1.5 kHz
        window = 200;
        bufLen = window + tauMax;
        hop = 48;
        ring.assign ((size_t) bufLen, 0.0f);
        frame.assign ((size_t) bufLen, 0.0f);
        diff.assign ((size_t) tauMax, 0.0);
        cmnd.assign ((size_t) tauMax, 0.0);
        lp1.setLowpass (sr, 1500.0, 0.7071);
        lp2.setLowpass (sr, 1500.0, 0.7071);
        reset();
    }

    void reset()
    {
        std::fill (ring.begin(), ring.end(), 0.0f);
        lp1.reset();
        lp2.reset();
        wr = 0; filled = 0; decimCounter = 0; sinceHop = 0;
        last = {};
    }

    // number of input samples of history that a reading depends on
    int windowInputSamples() const { return bufLen * decim; }

    // returns true when a new estimate is available
    bool push (float x)
    {
        const float y = lp2.process (lp1.process (x));
        if (++decimCounter < decim)
            return false;
        decimCounter = 0;

        ring[(size_t) wr] = y;
        wr = (wr + 1) % bufLen;
        if (filled < bufLen) ++filled;

        if (++sinceHop >= hop && filled == bufLen)
        {
            sinceHop = 0;
            analyse();
            return true;
        }
        return false;
    }

    const Result& result() const { return last; }

private:
    void analyse()
    {
        for (int i = 0; i < bufLen; ++i)
            frame[(size_t) i] = ring[(size_t) ((wr + i) % bufLen)];

        double energy = 0.0;
        for (int j = 0; j < window; ++j)
            energy += (double) frame[(size_t) j] * frame[(size_t) j];
        if (energy < 1e-9 * window) { last = {}; return; }

        for (int tau = 1; tau < tauMax; ++tau)
        {
            double s = 0.0;
            for (int j = 0; j < window; ++j)
            {
                const double d = (double) frame[(size_t) j] - (double) frame[(size_t) (j + tau)];
                s += d * d;
            }
            diff[(size_t) tau] = s;
        }

        cmnd[0] = 1.0;
        double run = 0.0;
        for (int tau = 1; tau < tauMax; ++tau)
        {
            run += diff[(size_t) tau];
            cmnd[(size_t) tau] = run > 0.0 ? diff[(size_t) tau] * tau / run : 1.0;
        }

        int best = -1;
        for (int t = tauMin; t < tauMax - 1; ++t)
        {
            if (cmnd[(size_t) t] < 0.15)
            {
                while (t + 1 < tauMax - 1 && cmnd[(size_t) (t + 1)] < cmnd[(size_t) t]) ++t;
                best = t;
                break;
            }
        }
        if (best < 0)
        {
            int mn = tauMin;
            for (int t = tauMin; t < tauMax - 1; ++t)
                if (cmnd[(size_t) t] < cmnd[(size_t) mn]) mn = t;
            if (cmnd[(size_t) mn] < 0.35) best = mn;
        }
        if (best < 1) { last = {}; return; }

        double tauF = best;
        if (best > 1 && best < tauMax - 1)
        {
            const double s0 = cmnd[(size_t) (best - 1)], s1 = cmnd[(size_t) best], s2 = cmnd[(size_t) (best + 1)];
            const double den = s0 - 2.0 * s1 + s2;
            if (std::abs (den) > 1e-12)
                tauF += std::clamp (0.5 * (s0 - s2) / den, -1.0, 1.0);
        }
        last.voiced = true;
        last.hz = dsr / tauF;
    }

    double sr = 48000.0, dsr = 12000.0;
    int decim = 4, tauMax = 165, tauMin = 8, window = 200, bufLen = 365, hop = 48;
    int wr = 0, filled = 0, decimCounter = 0, sinceHop = 0;
    std::vector<float> ring, frame;
    std::vector<double> diff, cmnd;
    Biquad lp1, lp2;
    Result last;
};

//------------------------------------------------------------------------------
// One plucked string: Karplus-Strong with fractional delay + one-pole damping.
class KSString
{
public:
    void prepare (double sampleRate)
    {
        sr = sampleRate;
        const int need = (int) (sr / 50.0) + 8;
        int size = 64;
        while (size < need) size <<= 1;
        buf.assign ((size_t) size, 0.0f);
        mask = size - 1;
        maxDelay = (float) (size - 4);
        clear();
    }

    void clear()
    {
        std::fill (buf.begin(), buf.end(), 0.0f);
        lp = 0.0f; excLp = 0.0f; exciteLeft = 0; w = 0;
    }

    void setTuning (double hz, double t60, double damping, bool snap)
    {
        hz = std::clamp (hz, 40.0, 4000.0);
        d = (float) damping;
        const double om = 2.0 * kPi * hz / sr;
        const double pd = std::atan2 (damping * std::sin (om), 1.0 - damping * std::cos (om)) / om;
        targetDelay = (float) std::clamp (sr / hz - pd, 2.0, (double) maxDelay);
        gain = (float) std::pow (10.0, -3.0 / (std::max (0.05, t60) * hz));
        gain = std::min (gain, 0.9999f);
        if (snap) delay = targetDelay;
    }

    void excite (float amp, float pickBrightness, uint32_t seed)
    {
        exciteAmp = amp;
        excP = 1.0f - pickBrightness * 0.85f;   // higher brightness -> less smoothing
        rng = seed | 1u;
        exciteLeft = (int) std::ceil (targetDelay) + 1;
    }

    float process()
    {
        delay += (targetDelay - delay) * 0.05f;

        const float rp = (float) w - delay;
        const int i0 = (int) std::floor (rp);
        const float fr = rp - (float) i0;
        const float y = buf[(size_t) (i0 & mask)] * (1.0f - fr) + buf[(size_t) ((i0 + 1) & mask)] * fr;

        lp = (1.0f - d) * y + d * lp;
        float in = gain * lp;

        if (exciteLeft > 0)
        {
            rng ^= rng << 13; rng ^= rng >> 17; rng ^= rng << 5;
            const float n = ((float) (rng & 0xFFFFu) / 32768.0f) - 1.0f;
            excLp = (1.0f - excP) * n + excP * excLp;
            in += exciteAmp * excLp;
            --exciteLeft;
        }
        buf[(size_t) (w & mask)] = in;
        w = (w + 1) & mask;
        return y;
    }

private:
    double sr = 48000.0;
    std::vector<float> buf;
    int mask = 0, w = 0, exciteLeft = 0;
    float maxDelay = 1000.0f, delay = 100.0f, targetDelay = 100.0f, gain = 0.99f, d = 0.3f, lp = 0.0f;
    float exciteAmp = 0.0f, excP = 0.3f, excLp = 0.0f;
    uint32_t rng = 12345u;
};

//------------------------------------------------------------------------------
struct Params
{
    int   mode = 0;                     // 0 maqam map, 1 quarter-tone snap, 2 free follow
    int   tonic = 0;                    // pitch class 0..11 (C..B)
    std::array<float, 12> offsets {};   // cents, by interval above tonic (from maqamOffsets)
    float bendFollow = 1.0f;            // 0..1
    float gateDb = -50.0f;
    float sustain = 1.2f;               // T60 in seconds
    float tone = 0.5f;                  // 0 dark .. 1 bright
    float pick = 0.6f;                  // pluck brightness
    float detuneCents = 4.0f;           // course detune
    float overlap = 0.5f;               // how long previous notes keep ringing
    float body = 0.6f;                  // body resonance amount
};

//------------------------------------------------------------------------------
class OudEngine
{
public:
    static constexpr int kVoices = 3;

    void prepare (double sampleRate)
    {
        sr = sampleRate;
        detector.prepare (sr);
        for (auto& v : voices) { v.s[0].prepare (sr); v.s[1].prepare (sr); v.decayMul = 1.0f; v.hz = v.targetHz = 220.0; }
        settleSamples = detector.windowInputSamples() + (int) (0.004 * sr);
        glideCoef = 1.0 - std::exp (-32.0 / (0.004 * sr));
        envFastA = 1.0f - std::exp (-1.0f / (0.0005f * (float) sr));
        envFastR = 1.0f - std::exp (-1.0f / (0.020f * (float) sr));
        envSlowA = 1.0f - std::exp (-1.0f / (0.015f * (float) sr));
        envSlowR = 1.0f - std::exp (-1.0f / (0.030f * (float) sr));
        lastBody = -1.0f;
        reset();
    }

    void reset()
    {
        detector.reset();
        for (auto& v : voices) { v.s[0].clear(); v.s[1].clear(); }
        for (auto& b : bodyL) b.reset();
        for (auto& b : bodyR) b.reset();
        envFast = envSlow = armPeak = 0.0f;
        armed = false; hasPitch = false; unvoicedFrames = 0; histCount = 0; clock = 0; lastOnset = -1000000;
        cur = 0; controlCounter = 0;
    }

    void setParams (const Params& p)
    {
        params = p;
        gateLin = std::pow (10.0f, p.gateDb / 20.0f);
        if (std::abs (p.body - lastBody) > 1e-4f)
        {
            lastBody = p.body;
            const double g = p.body;
            bodyL[0].setPeak (sr, 120.0, 1.6, 5.0 * g);
            bodyL[1].setPeak (sr, 260.0, 1.3, 3.0 * g);
            bodyL[2].setPeak (sr, 1500.0, 0.9, 2.5 * g);
            bodyL[3].setLowpass (sr, 5500.0, 0.7071);
            for (int i = 0; i < 4; ++i) bodyR[i] = bodyL[i];
        }
    }

    // One sample in, stereo oud out.
    void processSample (float in, float& outL, float& outR)
    {
        ++clock;
        const float a = std::abs (in);
        envFast += ((a > envFast) ? envFastA : envFastR) * (a - envFast);
        envSlow += ((a > envSlow) ? envSlowA : envSlowR) * (a - envSlow);

        if (envFast > gateLin && envFast > envSlow * 2.2f && (clock - lastOnset) > (int64_t) (0.045 * sr))
        {
            lastOnset = clock;
            armed = true;
            armStart = clock;
            armPeak = envFast;
        }
        if (armed) armPeak = std::max (armPeak, envFast);

        if (detector.push (in))
            onFrame (detector.result());

        if (++controlCounter >= 32) { controlCounter = 0; controlUpdate(); }

        float l = 0.0f, r = 0.0f;
        for (auto& v : voices)
        {
            const float s0 = v.s[0].process(), s1 = v.s[1].process();
            l += 0.75f * s0 + 0.25f * s1;
            r += 0.25f * s0 + 0.75f * s1;
        }
        for (auto& b : bodyL) l = b.process (l);
        for (auto& b : bodyR) r = b.process (r);
        outL = std::tanh (l);
        outR = std::tanh (r);
    }

private:
    struct Voice
    {
        KSString s[2];
        double hz = 220.0, targetHz = 220.0;
        float decayMul = 1.0f;
    };

    // ---- pitch -> output pitch mapping (in MIDI note units, fractional) ----
    double adjustAt (double x) const
    {
        const double fl = std::floor (x);
        const double fr = x - fl;
        const int i0 = (((int) fl - params.tonic) % 12 + 12) % 12;
        const double a0 = params.offsets[(size_t) i0] / 100.0;
        const double a1 = params.offsets[(size_t) ((i0 + 1) % 12)] / 100.0;
        return a0 + fr * (a1 - a0);
    }

    double mapPitch (double m)
    {
        if (params.mode == 2)
            return m;

        if (params.mode == 1)
        {
            if (std::abs (m - sticky24) > 0.33) sticky24 = std::round (m * 2.0) * 0.5;
            return sticky24 + params.bendFollow * (m - sticky24);
        }

        if (std::abs (m - sticky) > 0.65) sticky = std::round (m);
        const double used = sticky + params.bendFollow * (m - sticky);
        return used + adjustAt (used);
    }

    // ---- frame handling ----
    void onFrame (const PitchDetector::Result& r)
    {
        if (armed && (clock - armStart) > 3 * (int64_t) settleSamples)
            armed = false;

        if (! r.voiced)
        {
            if (++unvoicedFrames > 12) { hasPitch = false; histCount = 0; }
            return;
        }
        unvoicedFrames = 0;

        const double m = hzToMidi (r.hz);
        hist[2] = hist[1]; hist[1] = hist[0]; hist[0] = m;
        if (histCount < 3) ++histCount;
        if (histCount < 3) return;

        const double med = std::max (std::min (hist[0], hist[1]), std::min (std::max (hist[0], hist[1]), hist[2]));

        if (! hasPitch)
        {
            hasPitch = true;
            refM = med;
            sticky = std::round (med);
            sticky24 = std::round (med * 2.0) * 0.5;
            jumpCount = 0;
        }

        // legato events (hammer-on / pull-off): sudden jump without a pick attack
        if (std::abs (med - refM) > 0.7)
        {
            if (++jumpCount >= 3)
            {
                refM = med;
                sticky = std::round (med);
                sticky24 = std::round (med * 2.0) * 0.5;
                jumpCount = 0;
                if (! armed) pluck (mapPitch (med), 0.45f);
                return;
            }
        }
        else
        {
            jumpCount = 0;
            refM += 0.3 * (med - refM);
        }

        if (armed && (clock - armStart) >= settleSamples)
        {
            armed = false;
            refM = med;
            sticky = std::round (med);
            sticky24 = std::round (med * 2.0) * 0.5;
            const float vel = std::clamp (armPeak * 4.0f, 0.3f, 1.0f);
            pluck (mapPitch (med), vel);
            return;
        }

        voices[(size_t) cur].targetHz = midiToHz (mapPitch (med));
    }

    void pluck (double outMidi, float velocity)
    {
        // previous voice keeps ringing but decays faster depending on "overlap"
        voices[(size_t) cur].decayMul = 1.0f + (1.0f - params.overlap) * 14.0f;
        cur = (cur + 1) % kVoices;
        auto& v = voices[(size_t) cur];
        v.decayMul = 1.0f;
        v.s[0].clear();
        v.s[1].clear();
        v.hz = v.targetHz = midiToHz (outMidi);
        applyTuning (v, true);
        const uint32_t seed = (uint32_t) (clock * 2654435761u);
        v.s[0].excite (0.55f * velocity, params.pick, seed);
        v.s[1].excite (0.55f * velocity, params.pick, seed ^ 0x9E3779B9u);
    }

    void applyTuning (Voice& v, bool snap)
    {
        const double det = params.detuneCents;
        const double t60 = params.sustain / v.decayMul;
        const double damping = 0.62 - 0.57 * params.tone;      // tone 0 -> 0.62 (dark) .. 1 -> 0.05 (bright)
        v.s[0].setTuning (v.hz * std::pow (2.0, +det / 1200.0), t60, damping, snap);
        v.s[1].setTuning (v.hz * std::pow (2.0, -det / 1200.0), t60, damping, snap);
    }

    void controlUpdate()
    {
        for (auto& v : voices)
        {
            v.hz += (v.targetHz - v.hz) * glideCoef;
            applyTuning (v, false);
        }
    }

    Params params;
    double sr = 48000.0, glideCoef = 0.1;
    PitchDetector detector;
    std::array<Voice, kVoices> voices;
    std::array<Biquad, 4> bodyL, bodyR;
    float lastBody = -1.0f, gateLin = 0.003f;

    float envFast = 0, envSlow = 0, envFastA = 0, envFastR = 0, envSlowA = 0, envSlowR = 0, armPeak = 0;
    int64_t clock = 0, lastOnset = -1000000, armStart = 0;
    int settleSamples = 1500, unvoicedFrames = 0, histCount = 0, jumpCount = 0, cur = 0, controlCounter = 0;
    bool armed = false, hasPitch = false;
    double hist[3] { 0, 0, 0 }, refM = 60, sticky = 60, sticky24 = 60;
};

} // namespace oud
