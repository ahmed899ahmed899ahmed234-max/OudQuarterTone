#include "PluginProcessor.h"

using APVTS  = juce::AudioProcessorValueTreeState;
using PID    = juce::ParameterID;
using Range  = juce::NormalisableRange<float>;

APVTS::ParameterLayout OudQuarterToneProcessor::createLayout()
{
    APVTS::ParameterLayout l;

    l.add (std::make_unique<juce::AudioParameterChoice> (PID { "mode", 1 }, "Mode",
           juce::StringArray { "Maqam Map", "Quarter-Tone Snap", "Free Follow" }, 0));
    l.add (std::make_unique<juce::AudioParameterChoice> (PID { "maqam", 1 }, "Maqam",
           juce::StringArray { "Off (12-TET)", "Rast", "Bayati", "Sikah", "Custom" }, 1));
    l.add (std::make_unique<juce::AudioParameterChoice> (PID { "tonic", 1 }, "Tonic (guitar note)",
           juce::StringArray { "C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B" }, 0));

    l.add (std::make_unique<juce::AudioParameterFloat> (PID { "bend", 1 }, "Bend Follow", Range (0.0f, 1.0f, 0.01f), 1.0f));
    l.add (std::make_unique<juce::AudioParameterFloat> (PID { "gate", 1 }, "Input Gate (dB)", Range (-80.0f, -20.0f, 0.5f), -50.0f));
    l.add (std::make_unique<juce::AudioParameterFloat> (PID { "sustain", 1 }, "Sustain (s)", Range (0.2f, 4.0f, 0.01f, 0.6f), 1.2f));
    l.add (std::make_unique<juce::AudioParameterFloat> (PID { "tone", 1 }, "Tone", Range (0.0f, 1.0f, 0.01f), 0.5f));
    l.add (std::make_unique<juce::AudioParameterFloat> (PID { "pick", 1 }, "Pick Brightness", Range (0.0f, 1.0f, 0.01f), 0.6f));
    l.add (std::make_unique<juce::AudioParameterFloat> (PID { "detune", 1 }, "Course Detune (cents)", Range (0.0f, 15.0f, 0.1f), 4.0f));
    l.add (std::make_unique<juce::AudioParameterFloat> (PID { "overlap", 1 }, "Note Overlap", Range (0.0f, 1.0f, 0.01f), 0.5f));
    l.add (std::make_unique<juce::AudioParameterFloat> (PID { "body", 1 }, "Body Resonance", Range (0.0f, 1.0f, 0.01f), 0.6f));
    l.add (std::make_unique<juce::AudioParameterFloat> (PID { "wet", 1 }, "Oud Level", Range (0.0f, 1.5f, 0.01f), 1.0f));
    l.add (std::make_unique<juce::AudioParameterFloat> (PID { "dry", 1 }, "Dry Guitar Level", Range (0.0f, 1.0f, 0.01f), 0.0f));

    static const char* names[12] = { "Root", "+1 st", "+2 st", "+3 st", "+4 st", "+5 st",
                                     "+6 st", "+7 st", "+8 st", "+9 st", "+10 st", "+11 st" };
    for (int i = 0; i < 12; ++i)
        l.add (std::make_unique<juce::AudioParameterFloat> (PID { "c" + juce::String (i), 1 },
                                                            juce::String ("Custom: ") + names[i] + " (cents)",
                                                            Range (-100.0f, 100.0f, 1.0f), 0.0f));
    return l;
}

OudQuarterToneProcessor::OudQuarterToneProcessor()
    : AudioProcessor (BusesProperties()
                          .withInput  ("Input",  juce::AudioChannelSet::stereo(), true)
                          .withOutput ("Output", juce::AudioChannelSet::stereo(), true)),
      apvts (*this, nullptr, "STATE", createLayout())
{
}

void OudQuarterToneProcessor::prepareToPlay (double sampleRate, int samplesPerBlock)
{
    engine.prepare (sampleRate);
    monoIn.assign ((size_t) std::max (samplesPerBlock, 1), 0.0f);
    setLatencySamples (0);   // wet path lags ~40 ms behind the pick by nature (pitch detection)
}

bool OudQuarterToneProcessor::isBusesLayoutSupported (const BusesLayout& layouts) const
{
    const auto in  = layouts.getMainInputChannelSet();
    const auto out = layouts.getMainOutputChannelSet();
    if (out != juce::AudioChannelSet::stereo() && out != juce::AudioChannelSet::mono())
        return false;
    return in == juce::AudioChannelSet::mono() || in == juce::AudioChannelSet::stereo();
}

void OudQuarterToneProcessor::processBlock (juce::AudioBuffer<float>& buffer, juce::MidiBuffer&)
{
    juce::ScopedNoDenormals noDenormals;

    const int numIn  = getTotalNumInputChannels();
    const int numOut = getTotalNumOutputChannels();
    const int n      = buffer.getNumSamples();

    // parameters -> engine
    oud::Params p;
    p.mode        = (int) get ("mode");
    p.tonic       = (int) get ("tonic");
    std::array<float, 12> custom {};
    for (int i = 0; i < 12; ++i) custom[(size_t) i] = get (("c" + juce::String (i)).toRawUTF8());
    p.offsets     = oud::maqamOffsets ((int) get ("maqam"), custom);
    p.bendFollow  = get ("bend");
    p.gateDb      = get ("gate");
    p.sustain     = get ("sustain");
    p.tone        = get ("tone");
    p.pick        = get ("pick");
    p.detuneCents = get ("detune");
    p.overlap     = get ("overlap");
    p.body        = get ("body");
    engine.setParams (p);
    const float wet = get ("wet"), dry = get ("dry");

    if ((int) monoIn.size() < n) monoIn.assign ((size_t) n, 0.0f);   // rare: host used a bigger block

    for (int i = 0; i < n; ++i)
    {
        float s = 0.0f;
        for (int ch = 0; ch < numIn; ++ch) s += buffer.getReadPointer (ch)[i];
        monoIn[(size_t) i] = numIn > 0 ? s / (float) numIn : 0.0f;
    }

    for (int ch = numIn; ch < numOut; ++ch)
        buffer.clear (ch, 0, n);

    float* left  = buffer.getWritePointer (0);
    float* right = numOut > 1 ? buffer.getWritePointer (1) : nullptr;

    for (int i = 0; i < n; ++i)
    {
        float l, r;
        engine.processSample (monoIn[(size_t) i], l, r);
        const float d = monoIn[(size_t) i] * dry;
        if (right != nullptr) { left[i] = l * wet + d; right[i] = r * wet + d; }
        else                  { left[i] = 0.5f * (l + r) * wet + d; }
    }
}

juce::AudioProcessorEditor* OudQuarterToneProcessor::createEditor()
{
    return new juce::GenericAudioProcessorEditor (*this);
}

void OudQuarterToneProcessor::getStateInformation (juce::MemoryBlock& destData)
{
    if (auto xml = apvts.copyState().createXml())
        copyXmlToBinary (*xml, destData);
}

void OudQuarterToneProcessor::setStateInformation (const void* data, int sizeInBytes)
{
    if (auto xml = getXmlFromBinary (data, sizeInBytes))
        if (xml->hasTagName (apvts.state.getType()))
            apvts.replaceState (juce::ValueTree::fromXml (*xml));
}

juce::AudioProcessor* JUCE_CALLTYPE createPluginFilter()
{
    return new OudQuarterToneProcessor();
}
